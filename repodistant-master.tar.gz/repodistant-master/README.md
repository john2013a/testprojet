Clonez ce dépôt en local pour valider la configuration de votre client git.

Hello guys!