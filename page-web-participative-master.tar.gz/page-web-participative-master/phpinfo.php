<?php phpinfo(); ?>
<?php phpinfo(); ?>
